import os
import re
from model.traveller_map_api import TravellerMapAPI
from model.sectors_db import SectorDB
from model.planets_db import PlanetDB

class DataDownloadController:
    def __init__(self, db_instance):
        self.db_instance = db_instance
        self.api = TravellerMapAPI()  # create an instance of the API

    def download_all_data(self, view_widget):
        """
        Retrieves sector and planet data from the API, then updates the database.
        Status messages are written to the provided view_widget.
        """
        total_planets = 0
        try:
            # Retrieve universe data (expecting a JSON object with a "Sectors" key).
            universe_json = self.api.get_universe()
            if not (isinstance(universe_json, dict) and "Sectors" in universe_json):
                raise Exception("Universe data does not contain 'Sectors'.")
            sectors_json = universe_json["Sectors"]

            # Build a list of display names from the sector objects.
            display_sector_names = []
            for sector_obj in sectors_json:
                if not isinstance(sector_obj, dict):
                    continue
                official_name = ""
                if "Names" in sector_obj and isinstance(sector_obj["Names"], list) and sector_obj["Names"]:
                    official_name = sector_obj["Names"][0].get("Text", "")
                if not official_name:
                    official_name = sector_obj.get("Abbreviation", "")
                if official_name:
                    display_sector_names.append(official_name)
            view_widget.append("Retrieved sectors: " + ", ".join(display_sector_names))

            # Get database model instances.
            sector_db = SectorDB(self.db_instance)
            planet_db = PlanetDB(self.db_instance)
            
            # Process each sector using the original JSON objects.
            for sector_obj in sectors_json:
                if not isinstance(sector_obj, dict):
                    continue

                # Extract full sector information.
                official_name = ""
                if "Names" in sector_obj and isinstance(sector_obj["Names"], list) and sector_obj["Names"]:
                    official_name = sector_obj["Names"][0].get("Text", "")
                if not official_name:
                    official_name = sector_obj.get("Abbreviation", "")
                if not official_name:
                    view_widget.append("Skipping sector due to missing name/abbreviation.")
                    continue

                view_widget.append(f"Processing sector: {official_name}")

                # Build a full data dictionary for the sector.
                sector_data = {
                    "name": official_name,
                    "abbreviation": sector_obj.get("Abbreviation", ""),
                    "x_coordinate": sector_obj.get("X"),
                    "y_coordinate": sector_obj.get("Y"),
                    "milieu": sector_obj.get("Milieu", "")
                }
                # Upsert the sector record.
                sector_db.upsert_sector(sector_data)
                
                # Download the sector map image.
                try:
                    image_path = self.api.download_sector_image(official_name)
                    # Update the sector record with the image path.
                    sector_db.update_sector_image(official_name, image_path)
                    view_widget.append(f"Sector map for '{official_name}' downloaded and updated.")
                except Exception as e:
                    view_widget.append(f"Failed to download sector map for '{official_name}': {e}")
                
                # Retrieve SEC data for the sector.
                raw_sec = self.api.get_sector_sec(official_name)
                # Parse the SEC text into planet records using the API's parse_sec_line method.
                planets = []
                for line in raw_sec.splitlines():
                    if re.match(r"^\d{4}\s", line):  # lines starting with a 4-digit hex
                        parsed = self.api.parse_sec_line(line)
                        if parsed:
                            planets.append(parsed)
                
                # Process each planet record.
                default_planet_image = os.path.join("database", "content", "images", "planets", "default_planet.png")
                sector_planets = 0
                for planet in planets:
                    # Ensure there is an image path.
                    if "image_path" not in planet or not planet["image_path"]:
                        planet["image_path"] = default_planet_image
                    if planet_db.upsert_planet(planet):
                        sector_planets += 1

                view_widget.append(f"Processed {sector_planets} planet records for sector '{official_name}'.")
                total_planets += sector_planets

            view_widget.append(f"Downloaded data for {len(sectors_json)} sectors and processed {total_planets} planet records.")
        except Exception as e:
            view_widget.append("Error downloading all data: " + str(e))
