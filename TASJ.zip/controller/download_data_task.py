import os
import re
import time
from model.traveller_map_api import TravellerMapAPI

def download_data_task(db_instance, progress_queue, cancel_event):
    """
    Task to download sector and planet data.
    Reports progress messages via progress_queue.
    Checks cancel_event to abort early.
    """
    api = TravellerMapAPI()
    # Get database model instances.
    from model.sectors_db import SectorDB
    from model.planets_db import PlanetDB
    sector_db = SectorDB(db_instance)
    planet_db = PlanetDB(db_instance)
    
    total_planets = 0
    try:
        universe_json = api.get_universe()
        if not (isinstance(universe_json, dict) and "Sectors" in universe_json):
            progress_queue.put("Error: Universe data does not contain 'Sectors'.")
            return
        sectors_json = universe_json["Sectors"]

        # Build a display list of sector names.
        display_sector_names = []
        for sector_obj in sectors_json:
            if isinstance(sector_obj, dict):
                official_name = ""
                if "Names" in sector_obj and isinstance(sector_obj["Names"], list) and sector_obj["Names"]:
                    official_name = sector_obj["Names"][0].get("Text", "")
                if not official_name:
                    official_name = sector_obj.get("Abbreviation", "")
                if official_name:
                    display_sector_names.append(official_name)
        progress_queue.put("Retrieved sectors: " + ", ".join(display_sector_names))
        
        # Process each sector.
        for idx, sector_obj in enumerate(sectors_json):
            if cancel_event.is_set():
                progress_queue.put("Download cancelled by user.")
                return

            if not isinstance(sector_obj, dict):
                continue

            # Extract full sector information.
            official_name = ""
            if "Names" in sector_obj and isinstance(sector_obj["Names"], list) and sector_obj["Names"]:
                official_name = sector_obj["Names"][0].get("Text", "")
            if not official_name:
                official_name = sector_obj.get("Abbreviation", "")
            if not official_name:
                progress_queue.put("Skipping a sector due to missing name/abbreviation.")
                continue

            progress_queue.put(f"Processing sector: {official_name}")

            # Build sector data dictionary.
            sector_data = {
                "name": official_name,
                "abbreviation": sector_obj.get("Abbreviation", ""),
                "x_coordinate": sector_obj.get("X"),
                "y_coordinate": sector_obj.get("Y"),
                "milieu": sector_obj.get("Milieu", "")
            }
            # Upsert the sector record.
            sector_db.upsert_sector(sector_data)

            # Download the sector map image.
            try:
                image_path = api.download_sector_image(official_name)
                # Update the sector record with the image path.
                sector_db.update_sector_image(official_name, image_path)
                progress_queue.put(f"Sector map for '{official_name}' downloaded and updated.")
            except Exception as e:
                progress_queue.put(f"Failed to download sector map for '{official_name}': {e}")

            # Retrieve SEC data for the sector.
            raw_sec = api.get_sector_sec(official_name)
            # Parse SEC text into planet records.
            planets = []
            for line in raw_sec.splitlines():
                if re.match(r"^\d{4}\s", line):
                    parsed = api.parse_sec_line(line)
                    if parsed:
                        planets.append(parsed)
            
            # Process each planet record.
            default_planet_image = os.path.join("database", "content", "images", "planets", "default_planet.png")
            sector_planets = 0
            for planet in planets:
                if "image_path" not in planet or not planet["image_path"]:
                    planet["image_path"] = default_planet_image
                if planet_db.upsert_planet(planet):
                    sector_planets += 1

            progress_queue.put(f"Processed {sector_planets} planet records for sector '{official_name}'.")
            total_planets += sector_planets
            progress_queue.put(f"Progress: {idx+1}/{len(sectors_json)} sectors processed.")
            time.sleep(0.1)  # Simulate a short delay

        progress_queue.put(f"Downloaded data for {len(sectors_json)} sectors and processed {total_planets} planet records.")
    except Exception as e:
        progress_queue.put("Error downloading all data: " + str(e))
