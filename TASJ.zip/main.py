from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QTabWidget, QTextEdit, QMenuBar, QAction,
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QDialogButtonBox,
    QMessageBox, QWidget, QComboBox, QFontDialog, QInputDialog
)
from PyQt5.QtCore import QSettings, QSize, QPoint, Qt
from PyQt5.QtGui import QFont
import sys
import os
import configparser
from controller.data_download_controller import DataDownloadController
from dotenv import load_dotenv
from model.traveller_database import TravellerDatabase
from model.migrations import run_migrations
from controller.sectors_controller import SectorController
from controller.planets_controller import PlanetController
from controller.characters_controller import CharactersController
from controller.lifeforms_controller import LifeformsController
from controller.ships_controller import ShipsController
from controller.vehicals_controller import VehiclesController
from controller.events_controller import EventsController
from controller.technology_controller import TechnologyController
from controller.organizations_controller import OrganizationsController
from controller.adventure_hooks_controller import AdventureHooksController
from controller.SQLQueryController import SQLQueryController

# Import our API data module and model classes
import model.traveller_map_api as traveller_map_api
from model.sectors_db import SectorDB
from model.planets_db import PlanetDB

# Base stylesheets for light and dark themes
LIGHT_STYLESHEET = """
QMainWindow {
    background-color: white;
    color: black;
}
QTextEdit {
    background-color: #f0f0f0;
    color: black;
}
QPushButton {
    background-color: #e0e0e0;
    color: black;
}
"""

DARK_STYLESHEET = """
QMainWindow {
    background-color: #2e2e2e;
    color: white;
}
QTextEdit {
    background-color: #4a4a4a;
    color: white;
}
QPushButton {
    background-color: #3a3a3a;
    color: white;
}
"""

class SettingsDialog(QDialog):
    """
    Dialog for selecting theme (Light/Dark) and choosing a font via QFontDialog.
    """
    def __init__(self, current_theme, current_font, parent=None):
        super(SettingsDialog, self).__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(300, 150)
        layout = QVBoxLayout()

        # Theme selection
        theme_layout = QHBoxLayout()
        theme_label = QLabel("Theme:")
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Light", "Dark"])
        index = self.theme_combo.findText(current_theme)
        if index >= 0:
            self.theme_combo.setCurrentIndex(index)
        theme_layout.addWidget(theme_label)
        theme_layout.addWidget(self.theme_combo)
        layout.addLayout(theme_layout)

        # Font selection
        font_layout = QHBoxLayout()
        font_label = QLabel("Font:")
        self.font_button = QPushButton("Choose Font")
        self.font_display = QLabel(f"{current_font.family()} {current_font.pointSize()}")
        font_layout.addWidget(font_label)
        font_layout.addWidget(self.font_display)
        font_layout.addWidget(self.font_button)
        layout.addLayout(font_layout)

        self.selected_font = current_font
        self.font_button.clicked.connect(self.choose_font)

        # OK/Cancel buttons
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(button_box)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)

        self.setLayout(layout)

    def choose_font(self):
        font, ok = QFontDialog.getFont(self.selected_font, self, "Select Font")
        if ok:
            self.selected_font = font
            self.font_display.setText(f"{font.family()} {font.pointSize()}")

class HitchhikersGuideToTheGalaxy(QMainWindow):
    def __init__(self):
        super().__init__()
        print("Initializing HitchhikersGuideToTheGalaxy window...")

        # Load environment variables and config defaults
        load_dotenv('config/.env', override=True)
        db_type = os.getenv('DATABASE_TYPE')
        print(f"Database type is: {db_type}")
        if db_type not in ['sqlite', 'mysql']:
            raise ValueError("Unsupported database type.")

        # Read defaults from config/.config
        config_parser = configparser.ConfigParser()
        config_parser.read('config/.config')
        default_theme = config_parser.get('Display', 'theme', fallback='Light').capitalize()
        default_width = config_parser.getint('Display', 'window_width', fallback=1024)
        default_height = config_parser.getint('Display', 'window_height', fallback=768)
        default_x = config_parser.getint('Display', 'window_x', fallback=100)
        default_y = config_parser.getint('Display', 'window_y', fallback=50)

        # Initialize QSettings to persist user settings
        self.qsettings = QSettings("YourCompany", "TASJ")
        window_size = self.qsettings.value("windowSize", QSize(default_width, default_height))
        window_pos = self.qsettings.value("windowPos", QPoint(default_x, default_y))
        self.resize(window_size)
        self.move(window_pos)

        self.current_theme = self.qsettings.value("theme", default_theme)
        font_string = self.qsettings.value("font", "")
        if font_string:
            self.current_font = QFont()
            self.current_font.fromString(font_string)
        else:
            self.current_font = QFont("Arial", 10)

        # Initialize DB and controllers
        self.setWindowTitle("Hitchhikers Guide to the Galaxy")
        self.db_instance = TravellerDatabase(db_type)

        self.sector_controller = SectorController(self.db_instance)
        self.planet_controller = PlanetController(self.db_instance)
        self.characters_controller = CharactersController(self.db_instance)
        self.lifeforms_controller = LifeformsController(self.db_instance)
        self.events_controller = EventsController(self.db_instance)
        self.organizations_controller = OrganizationsController(self.db_instance)
        self.adventure_hooks_controller = AdventureHooksController(self.db_instance)
        self.ships_controller = ShipsController(self.db_instance)
        self.vehicals_controller = VehiclesController(self.db_instance)
        self.technology_controller = TechnologyController(self.db_instance)
        self.sql_query_controller = SQLQueryController(self.db_instance)
        
        # Initialize the new DataDownloadController
        self.data_download_controller = DataDownloadController(self.db_instance)
        
        self.init_ui()
        self.apply_theme_and_font()

    def init_ui(self):
        print("Setting up UI...")
        menubar = QMenuBar(self)
        self.setMenuBar(menubar)

        # File Menu
        file_menu = menubar.addMenu("File")
        action_settings = QAction("Settings", self)
        file_menu.addAction(action_settings)
        action_settings.triggered.connect(self.open_settings)
        action_exit = QAction("Exit", self)
        file_menu.addAction(action_exit)
        action_exit.triggered.connect(self.close)

        # Database Menu
        db_menu = menubar.addMenu("Database")
        action_run_migrations = QAction("Run Migrations", self)
        db_menu.addAction(action_run_migrations)
        action_run_migrations.triggered.connect(self.run_migrations)
        action_run_sql = QAction("SQL Query", self)
        db_menu.addAction(action_run_sql)
        action_run_sql.triggered.connect(self.run_sql)
        action_download_sector = QAction("Download Sector Data", self)
        db_menu.addAction(action_download_sector)
        action_download_sector.triggered.connect(self.download_sector_data)
        action_download_planets = QAction("Download Planet Data", self)
        db_menu.addAction(action_download_planets)
        action_download_planets.triggered.connect(self.download_planet_data)
        action_download_all = QAction("Download All Data", self)
        db_menu.addAction(action_download_all)
        action_download_all.triggered.connect(self.download_all_data)
        
        # Tabbed interface
        self.tabs = QTabWidget()
        self.sector_view = QTextEdit()
        self.planet_view = QTextEdit()
        self.people_view = QTextEdit()
        self.lifeforms_view = QTextEdit()
        self.ships_view = QTextEdit()
        self.vehicals_view = QTextEdit()
        self.events_view = QTextEdit()
        self.technology_view = QTextEdit()
        self.organizations_view = QTextEdit()
        self.adventure_hooks_view = QTextEdit()
        
        self.tabs.addTab(self.sector_view, "Sectors")
        self.tabs.addTab(self.planet_view, "Planets")
        self.tabs.addTab(self.people_view, "People")
        self.tabs.addTab(self.lifeforms_view, "Lifeforms")
        self.tabs.addTab(self.ships_view, "Ships")
        self.tabs.addTab(self.vehicals_view, "Vehicles")
        self.tabs.addTab(self.events_view, "Events")
        self.tabs.addTab(self.technology_view, "Technology")
        self.tabs.addTab(self.organizations_view, "Organizations")
        self.tabs.addTab(self.adventure_hooks_view, "Adventure Hooks")
        self.tabs.currentChanged.connect(self.on_tab_changed)
        
        self.lower_text_box = QTextEdit(self)
        self.lower_text_box.setReadOnly(True)
        
        main_layout = QVBoxLayout()
        main_layout.addWidget(self.tabs)
        main_layout.addWidget(self.lower_text_box)
        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)

        self.statusBar().showMessage("Ready")
        print("UI setup complete.")

    def apply_theme_and_font(self):
        base_sheet = DARK_STYLESHEET if self.current_theme == "Dark" else LIGHT_STYLESHEET
        font_family = self.current_font.family()
        font_size = self.current_font.pointSize()
        font_override = f"""
        QMainWindow, QMenuBar, QTabBar, QTabWidget, QPushButton,
        QTextEdit, QLabel, QComboBox, QDialogButtonBox {{
            font-family: "{font_family}";
            font-size: {font_size}pt;
        }}
        """
        final_stylesheet = base_sheet + font_override
        self.setStyleSheet(final_stylesheet)

    def open_settings(self):
        dialog = SettingsDialog(self.current_theme, self.current_font, self)
        if dialog.exec_() == QDialog.Accepted:
            self.current_theme = dialog.theme_combo.currentText()
            self.current_font = dialog.selected_font
            self.apply_theme_and_font()
            self.qsettings.setValue("theme", self.current_theme)
            self.qsettings.setValue("font", self.current_font.toString())
            QMessageBox.information(self, "Settings", "Settings saved successfully.")

    def on_tab_changed(self, index):
        if index == 0:
            self.sector_controller.show_view(self.lower_text_box)
        elif index == 1:
            self.planet_controller.show_view(self.lower_text_box)
        elif index == 2:
            self.characters_controller.show_view(self.lower_text_box)
        elif index == 3:
            self.lifeforms_controller.show_view(self.lower_text_box)
        elif index == 4:
            self.ships_controller.show_view(self.lower_text_box)
        elif index == 5:
            self.vehicals_controller.show_view(self.lower_text_box)
        elif index == 6:
            self.events_controller.show_view(self.lower_text_box)
        elif index == 7:
            self.technology_controller.show_view(self.lower_text_box)
        elif index == 8:
            self.organizations_controller.show_view(self.lower_text_box)
        elif index == 9:
            self.adventure_hooks_controller.show_view(self.lower_text_box)
        else:
            self.lower_text_box.setPlainText("No data available for this tab.")

    def run_migrations(self):
        db_type = os.getenv('DATABASE_TYPE')
        run_migrations(db_type)
        QMessageBox.information(self, "Migrations", "Migrations have been run successfully.")

    def run_sql(self):
        self.sector_controller.show_view(self.lower_text_box)

    def download_sector_data(self):
        sector, ok = QInputDialog.getText(self, "Download Sector Data", "Enter Sector Name:")
        if ok and sector:
            self.lower_text_box.append(f"Downloading sector data for: {sector}")
            try:
                if traveller_map_api.download_sector_map(sector, self.db_instance):
                    self.lower_text_box.append("Sector map downloaded and database updated.")
                else:
                    self.lower_text_box.append("Failed to download sector map.")
            except Exception as e:
                self.lower_text_box.append(f"Error: {str(e)}")
        else:
            self.lower_text_box.append("Download sector data canceled.")

    def download_planet_data(self):
        sector, ok = QInputDialog.getText(self, "Download Planet Data", "Enter Sector Name:")
        if ok and sector:
            self.lower_text_box.append(f"Downloading planet data for: {sector}")
            try:
                planets = traveller_map_api.get_sector_data(sector)
                default_planet_image = os.path.join("database", "content", "images", "planets", "default_black.png")
                from model.planets_db import PlanetDB
                planet_db = PlanetDB(self.db_instance)
                count = 0
                for planet in planets:
                    if "image_path" not in planet or not planet["image_path"]:
                        planet["image_path"] = default_planet_image
                    if planet_db.upsert_planet(planet):
                        count += 1
                self.lower_text_box.append(f"Processed {count} planet records from sector '{sector}'.")
            except Exception as e:
                self.lower_text_box.append(f"Error: {str(e)}")
        else:
            self.lower_text_box.append("Download planet data canceled.")

    def download_all_data(self):
        """
        Delegates the download of all data to the DataDownloadController,
        which fetches API data, updates the database, and writes status messages to the view.
        """
        self.data_download_controller.download_all_data(self.lower_text_box)

    def closeEvent(self, event):
        self.qsettings.setValue("windowPos", self.pos())
        self.qsettings.setValue("windowSize", self.size())
        super().closeEvent(event)

    def show_sector(self):
        self.sector_controller.show_view(self.lower_text_box)

    def show_planet(self):
        self.planet_controller.show_view(self.lower_text_box)

    def show_people(self):
        self.characters_controller.show_view(self.lower_text_box)

    def show_lifeforms(self):
        self.lifeforms_controller.show_view(self.lower_text_box)

    def show_ships(self):
        self.ships_controller.show_view(self.lower_text_box)

    def show_technology(self):
        self.technology_controller.show_view(self.lower_text_box)

    def show_vehicals(self):
        self.vehicals_controller.show_view(self.lower_text_box)
        
    def show_events(self):
        self.events_controller.show_view(self.lower_text_box)
    
    def show_organizations(self):
        self.organizations_controller.show_view(self.lower_text_box)

    def show_adventure_hooks(self):
        self.adventure_hooks_controller.show_view(self.lower_text_box)

    def run_sql(self):
        self.sector_controller.show_view(self.lower_text_box)

if __name__ == "__main__":
    print("Starting application...")
    app = QApplication(sys.argv)
    window = HitchhikersGuideToTheGalaxy()
    window.show()
    print("Showing window...")
    sys.exit(app.exec())
